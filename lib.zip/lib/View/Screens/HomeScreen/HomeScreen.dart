import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

import 'SubScreens/TicketScreen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return WillPopScope(
      onWillPop: () async {
        SystemNavigator.pop();
        return false;
      },
      child: Scaffold(
        backgroundColor: const Color(0xFFEAF4FF),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: width * 0.06),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: height * 0.03),

                  /// Top Bar: Profile + Greeting + Ticket
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Icon(
                              Icons.person,
                              color: const Color(0xFFA4A4A4),
                              size: 22,
                            ),
                          ),

                          const SizedBox(width: 10),
                          Text(
                            "Hi, 👋",
                            style: GoogleFonts.montserrat(
                              fontSize: 20,
                              fontWeight: FontWeight.w600,
                              color: const Color(0xFF333333),
                            ),
                          ),
                        ],
                      ),
                      GestureDetector(
                        onTap: () {
                          print("Ticket icon clicked");

                          Navigator.pushReplacement(
                            context,
                            MaterialPageRoute(builder: (_) => TicketScreen()),
                          );
                        },
                        child: Row(
                          children: [
                            Image.asset(
                              'assets/Png/Ticket.png',
                              width: 80,
                              height: 40,
                              fit: BoxFit.contain,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),

                  SizedBox(height: height * 0.03),

                  /// Active Ticket Card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: Colors.grey.shade200),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        /// Location Title
                        Row(
                          children: [
                            Image.asset(
                              'assets/Png/Train.png',
                              width: 32,
                              height: 32,
                              fit: BoxFit.contain,
                            ),

                            const SizedBox(width: 8),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  "Kodambakkam",
                                  style: GoogleFonts.montserrat(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF333333),
                                  ),
                                ),
                                Text(
                                  "Railway Station",
                                  style: GoogleFonts.montserrat(
                                    fontSize: 12,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF777777),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 16),

                        /// In & Out Times
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildTimeColumn(
                              "In time",
                              "07-12-2024",
                              "09.44 AM",
                            ),

                            _buildTimeColumn(
                              "Out time",
                              "07-12-2024",
                              "05.48 AM",
                            ),
                          ],
                        ),

                        const SizedBox(height: 16),
                        Divider(),

                        /// Amount & Duration
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _buildAmountOrDuration("Total Amount", "₹ 25"),
                            _buildAmountOrDuration(
                              "Total Hours",
                              "8 hours 21 minutes",
                            ),
                          ],
                        ),

                        const SizedBox(height: 16),

                        /// Pay Now Button
                        SizedBox(
                          width: double.infinity,
                          height: 45,
                          child: ElevatedButton(
                            onPressed: () {},
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00448C),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                            child: Text(
                              "Pay Now",
                              style: GoogleFonts.montserrat(
                                fontSize: 16,
                                color: Colors.white,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: height * 0.04),

                  /// Past Tickets Header
                  Text(
                    "Past Tickets",
                    style: GoogleFonts.montserrat(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 12),

                  /// Past Ticket Cards
                  _buildPastTicket(
                    "Kodambakkam",
                    "Bus Stand",
                    "11:33 PM • 11-07-2025",
                    true,
                  ),
                  _buildPastTicket(
                    "Saidapet",
                    "Railway Station",
                    "11:33 PM • 11-07-2025",
                    false,
                  ),
                  _buildPastTicket(
                    "Saidapet",
                    "Railway Station",
                    "11:33 PM • 11-07-2025",
                    false,
                  ),
                  _buildPastTicket(
                    "Saidapet",
                    "Railway Station",
                    "11:33 PM • 11-07-2025",
                    false,
                  ),

                  const SizedBox(height: 25),

                  /// View All + SVG
                  Center(
                    child: Column(
                      children: [
                        GestureDetector(
                          onTap: () {
                            print("View icon clicked");
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (_) => TicketScreen()),
                            );
                          },
                          child: Text(
                            "View All >>>",
                            style: GoogleFonts.montserrat(
                              color: const Color(0xFF00448C),
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                            ),
                          ),
                        ),

                        const SizedBox(height: 25),
                        Image.asset(
                          'assets/Png/BottomParking.png',
                          width: width,
                          fit: BoxFit.contain,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimeColumn(String label, String date, String time) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.montserrat(
            fontSize: 12,
            color: const Color(0xFF606060),
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          date,
          style: GoogleFonts.montserrat(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: const Color(0xFF575656),
          ),
        ),
        const SizedBox(height: 5),
        Row(
          children: [
            Icon(Icons.access_time, size: 20, color: const Color(0xFF130101)),
            const SizedBox(width: 4),
            Text(
              time,
              style: GoogleFonts.montserrat(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color:const Color(0xFF0C0101),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildAmountOrDuration(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: GoogleFonts.montserrat(
            fontSize: 12,
            color: const Color(0xFF606060),
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: GoogleFonts.montserrat(
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildPastTicket(
    String location,
    String sub,
    String datetime,
    bool isPaid,
  ) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Image.asset(
            'assets/Png/Train2.png',
            width: 24,
            height: 24,
            fit: BoxFit.contain,
          ),

          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  location,
                  style: GoogleFonts.montserrat(fontWeight: FontWeight.w600),
                ),
                Text(
                  sub,
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    color: const Color(0xFF606060),
                    fontWeight: FontWeight.w500,
                  ),
                ),
                Text(
                  datetime,
                  style: GoogleFonts.montserrat(
                    fontSize: 12,
                    color: const Color(0xFF4A4A4A),
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Text(
            isPaid ? "Paid" : "Unpaid",
            style: GoogleFonts.montserrat(
              fontWeight: FontWeight.w600,
              fontSize: 14,
              color: isPaid ? Colors.green : Colors.red,
            ),
          ),
        ],
      ),
    );
  }
}
